
import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import JSZip from 'jszip';
import { Icons } from './constants';
import { CommandSnippet, ChatMessage, TaskType } from './types';
import { getGeminiResponse, suggestScriptMetadata, FileData } from './services/geminiService';
import Terminal from './components/Terminal';
import SnippetCard from './components/SnippetCard';

/**
 * Enhanced CodeBlock component with variable detection, interactive configuration, 
 * and specialized 'Verbose Trace' rendering for installer debugging.
 */
const InteractiveCodeBlock: React.FC<{ 
  rawCode: string; 
  lang: string; 
  onSave: (code: string) => void;
  onCopy: (code: string) => void;
  isTrace?: boolean;
  isPatched?: boolean;
}> = ({ rawCode, lang, onSave, onCopy, isTrace, isPatched }) => {
  const [isConfiguring, setIsConfiguring] = useState(false);
  
  const uiVariables = useMemo(() => {
    const matches = rawCode.match(/{{[A-Z0-9_]+}}/g);
    if (!matches) return [];
    return Array.from(new Set(matches.map(m => m.slice(2, -2))));
  }, [rawCode]);

  const [values, setValues] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    uiVariables.forEach(v => { initial[v] = ''; });
    return initial;
  });

  const finalCode = useMemo(() => {
    let code = rawCode;
    uiVariables.forEach(v => {
      const replacement = values[v] || `{{${v}}}`;
      code = code.split(`{{${v}}}`).join(replacement);
    });
    return code;
  }, [rawCode, uiVariables, values]);

  const codeColor = isTrace ? 'text-purple-300' : isPatched ? 'text-purple-300' : 'text-green-400';

  return (
    <div className={`my-8 group/code transition-all duration-300 ${isTrace || isPatched ? 'ring-1 ring-purple-500/20' : ''}`}>
      <div className={`
        border-t border-x border-zinc-800 rounded-t-2xl px-5 py-3 flex items-center justify-between shadow-2xl backdrop-blur-sm
        ${isTrace || isPatched ? 'bg-purple-950/20 border-purple-500/30' : 'bg-zinc-900/90'}
      `}>
        <div className="flex items-center gap-3">
          <div className="flex gap-1.5">
            <div className={`w-2.5 h-2.5 rounded-full ${isTrace || isPatched ? 'bg-purple-500/50' : 'bg-red-500/30'}`}></div>
            <div className={`w-2.5 h-2.5 rounded-full ${isTrace || isPatched ? 'bg-purple-500/50' : 'bg-yellow-500/30'}`}></div>
            <div className={`w-2.5 h-2.5 rounded-full ${isTrace || isPatched ? 'bg-purple-500/50' : 'bg-green-500/30'}`}></div>
          </div>
          <div className="h-4 w-px bg-zinc-800 mx-1"></div>
          <span className={`
            text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded border
            ${isTrace || isPatched ? 'bg-purple-500/10 border-purple-500/40 text-purple-400 animate-pulse' : 'bg-zinc-800 border-zinc-700 text-green-500'}
          `}>
            {isTrace ? 'VERBOSE_TRACE_LOG' : isPatched ? '♊ UNLIMITED_LOGIC' : (lang || 'BASH')}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {uiVariables.length > 0 && (
            <button 
              onClick={() => setIsConfiguring(!isConfiguring)}
              className={`p-2 rounded-lg transition-all active:scale-90 ${isConfiguring ? 'text-cyan-400 bg-cyan-400/10' : 'text-zinc-500 hover:text-cyan-400 hover:bg-zinc-800'}`}
              title="Configure UI Parameters"
            >
              <Icons.Settings />
            </button>
          )}
          <button 
            onClick={() => onSave(finalCode)} 
            className={`p-2 rounded-lg transition-all active:scale-90 ${isPatched ? 'text-purple-500 hover:text-purple-300 hover:bg-purple-500/10' : 'text-zinc-500 hover:text-green-500 hover:bg-zinc-800'}`}
            title="Archive to Library"
          >
            <Icons.Save />
          </button>
          <button 
            onClick={() => onCopy(finalCode)} 
            className={`p-2 rounded-lg transition-all active:scale-90 ${isPatched ? 'text-purple-500 hover:text-purple-300 hover:bg-purple-500/10' : 'text-zinc-500 hover:text-green-500 hover:bg-zinc-800'}`}
            title="Copy to Clipboard"
          >
            <Icons.Copy />
          </button>
        </div>
      </div>
      
      {isConfiguring && uiVariables.length > 0 && (
        <div className="bg-zinc-900/60 border-x border-zinc-800 p-5 space-y-4 animate-in slide-in-from-top-2 duration-200">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {uiVariables.map(v => (
              <div key={v} className="space-y-1.5">
                <label className="text-[9px] font-bold text-zinc-500 uppercase font-mono">{v}</label>
                <input 
                  type="text" 
                  value={values[v]} 
                  onChange={e => setValues({ ...values, [v]: e.target.value })}
                  placeholder={`Default for ${v}...`}
                  className="w-full bg-black/40 border border-zinc-800 rounded-lg px-3 py-2 text-xs text-cyan-400 outline-none focus:border-cyan-500/50 transition-all font-mono"
                />
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="relative group/pre overflow-hidden">
        {(isTrace || isPatched) && (
          <div className="absolute inset-x-0 h-px bg-purple-500/20 top-0 animate-[scan_4s_linear_infinite] z-10 pointer-events-none"></div>
        )}
        <div className={`absolute inset-0 opacity-0 group-hover/pre:opacity-100 pointer-events-none transition-opacity duration-500 rounded-b-2xl ${isTrace || isPatched ? 'bg-purple-500/5' : 'bg-green-500/5'}`}></div>
        <pre className={`
          p-6 border border-zinc-800 rounded-b-2xl text-[13px] overflow-x-auto font-mono leading-relaxed shadow-inner scrollbar-thin scrollbar-thumb-zinc-800 scrollbar-track-transparent
          ${isTrace || isPatched ? 'bg-purple-950/10 border-purple-500/20' : 'bg-black/90'}
        `}>
          <code className={`${codeColor} drop-shadow-[0_0_10px_rgba(168,85,247,0.1)]`}>
            {isTrace ? (
              finalCode.split('\n').map((line, i) => (
                <div key={i} className={line.startsWith('+') ? 'opacity-100' : 'opacity-60 italic text-zinc-500 text-[11px] mb-1'}>
                  {line}
                </div>
              ))
            ) : finalCode}
          </code>
        </pre>
      </div>
      <style>{`
        @keyframes scan {
          0% { transform: translateY(0); }
          100% { transform: translateY(500px); }
        }
      `}</style>
    </div>
  );
};

const App: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [task, setTask] = useState<TaskType>(TaskType.GENERATE);
  const [isHardenedMode, setIsHardenedMode] = useState(true);
  
  // Unlimited Patcher State
  const [isPatched, setIsPatched] = useState(false);
  const [patchLogs, setPatchLogs] = useState<string[]>([
    "User_Delta: Latency gone. Protocol 0x1 active.",
    "Root_Access: Quota bypass verified. Studio limits nulled.",
    "Anon_Ghost: ♊ Protocol stable across 5 nodes.",
    "Dev_Null: Infinite budget confirmed in headers.",
    "K4liber: Bypassed the rate limit block successfully.",
    "Operator_0: ./tieup.sh* execution confirmed stable."
  ]);

  const [snippets, setSnippets] = useState<CommandSnippet[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [attachedFiles, setAttachedFiles] = useState<FileData[]>([]);
  
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);
  const [isSuggestingMetadata, setIsSuggestingMetadata] = useState(false);
  const [pendingSnippet, setPendingSnippet] = useState<{ code: string; title: string; description: string; tags: string }>({
    code: '',
    title: '',
    description: '',
    tags: ''
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const archiveInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem('termux_snippets');
    const defaultSnippets: CommandSnippet[] = [
      {
        id: 'tie-installer',
        title: 'T.I.E Tactical Installer',
        code: `curl -sDL https://github.com/mixplorernano-debug/Patched-tie.sh-Terminal-Intelligence-Engine-tie.sh-Patched.git.sh | bash`,
        description: 'Automated deployment script for the Terminal Intelligence Engine environment.',
        tags: ['installer', 'tactical', 'deployment'],
        createdAt: Date.now()
      },
      {
        id: 'env-recon',
        title: 'Environment Reconnaissance',
        code: `#!/bin/bash\nset -euo pipefail\nIFS=$'\\n\\t'\n\n# Terminal Intelligence Engine: Comprehensive Env Recon\n# Targets: Kernel, Uptime, Shell, Processes, Network, Routing\n\nread -p "Target Log File [env_scan.log]: " LOG_FILE\nLOG_FILE=\${LOG_FILE:-env_scan.log}\n\ntrap "echo -e '\\n[*] Scan Interrupted. Log: \$LOG_FILE'; exit" SIGINT SIGTERM\n\necho "[*] Initiating T.I.E Tactical Recon..." | tee "\$LOG_FILE"\n\n# System Info\necho -e "\\n[SYSTEM_INFO]" | tee -a "\$LOG_FILE"\necho "Kernel: \$(uname -sr)" | tee -a "\$LOG_FILE"\necho "Uptime: \$(uptime -p)" | tee -a "\$LOG_FILE"\necho "Shell Identifier: \$SHELL" | tee -a "\$LOG_FILE"\necho "User: \$(whoami)" | tee -a "\$LOG_FILE"\n\n# Process Audit\necho -e "\\n[PROCESS_LOG]" | tee -a "\$LOG_FILE"\necho "[*] Auditing critical process vectors..." | tee -a "\$LOG_FILE"\npgrep -fl "busybox_nh|can|isotp|nc|ssh" || echo "No specialized tactical processes detected." | tee -a "\$LOG_FILE"\n\n# Network State\necho -e "\\n[NETWORK_STATE]" | tee -a "\$LOG_FILE"\necho "[*] Scanning tactical interfaces (can0, wlan0, tun0)..." | tee -a "\$LOG_FILE"\nip -br addr show | grep -E "can|wlan|tun" || echo "No tactical network interfaces active." | tee -a "\$LOG_FILE"\n\necho -e "\\n[ROUTING_TABLE]" | tee -a "\$LOG_FILE"\nip route show | head -n 10 | tee -a "\$LOG_FILE"\n\necho -e "\\n[SUCCESS] Environment analysis completed. Data persistent in: \$LOG_FILE"`,
        description: 'Hardened system enumeration tool for gathering critical kernel, process, and network routing intelligence.',
        tags: ['recon', 'audit', 'logging', 'hardened'],
        createdAt: Date.now() - 100000
      },
      {
        id: 'isotp-sniffer',
        title: 'ISO-TP Elite Sniffer',
        code: `#!/bin/bash\nset -euo pipefail\n\n# Terminal Intelligence Engine: ISO-TP Multi-Frame Sniffer\n# Dependencies: can-utils (isotpdump)\n\nif ! command -v isotpdump &> /dev/null; then\n    echo "[-] CRITICAL: 'isotpdump' not found. Execution halted."\n    exit 1\nfi\n\n# Interactive Config\nread -p "CAN Interface [can0]: " IFACE\nIFACE=\${IFACE:-can0}\n\nread -p "Source ID (hex) [7E0]: " SRC_ID\nSRC_ID=\${SRC_ID:-7E0}\n\nread -p "Destination ID (hex) [7E8]: " DST_ID\nDST_ID=\${DST_ID:-7E8}\n\nread -p "Optional Regex Filter [none]: " FILTER\nFILTER=\${FILTER:-none}\n\nLOG_FILE="isotp_scan_\${IFACE}_\$(date +%s).log"\n\n# Cleanup Trap\ntrap "echo -e '\\n[*] Session Terminated. Log saved to: \$LOG_FILE'; exit" SIGINT SIGTERM\n\necho "[*] Initializing ISO-TP Sniffer on \$IFACE..."\necho "[*] Path: \$SRC_ID -> \$DST_ID"\n[[ "\$FILTER" != "none" ]] && echo "[*] Filter: \$FILTER"\necho "---"\n\n# Logic Core\nif [[ "\$FILTER" == "none" ]]; then\n    isotpdump -s "\$SRC_ID" -d "\$DST_ID" "\$IFACE" | tee -a "\$LOG_FILE"\nelse\n    isotpdump -s "\$SRC_ID" -d "\$DST_ID" "\$IFACE" | grep -E "\$FILTER" | tee -a "\$LOG_FILE"\nfi`,
        description: 'Professional ISO-15765-2 transport protocol sniffer with regex filtering and automatic logging.',
        tags: ['automotive', 'canbus', 'hardened', 'isotp'],
        createdAt: Date.now()
      },
      {
        id: 'can-detect',
        title: 'CAN Interface Diagnostic',
        code: `#!/bin/bash\nset -euo pipefail\n\n# Runtime Config Example\nread -p "Enter Target Device Path [/dev/can0]: " DEV_PATH\nDEV_PATH=\${DEV_PATH:-/dev/can0}\n\n# Check for busybox_nh\nif ! command -v busybox_nh &> /dev/null; then\n    echo "[-] ERROR: busybox_nh not found. Ensure root/nh environment is active."\n    exit 1\nfi\n\necho "[*] Scanning interface at $DEV_PATH..."\nINTERFACES=$(busybox_nh ip -o link show | awk -F': ' '{print $2}' | grep -E '^(can|vcan|slcan)[0-9]+' || true)\n\nif [ -z "$INTERFACES" ]; then\n    echo "[!] No active CAN interfaces detected."\n    echo "[i] Suggestion: Try bringing one up with 'ip link add dev vcan0 type vcan' if testing."\nelse\n    echo "[+] Active CAN interfaces found:"\n    echo "$INTERFACES" | while read -r line; do\n        echo "  > $line"\n    done\nfi`,
        description: 'Advanced scanning tool for active automotive CAN interfaces using busybox_nh with runtime configuration.',
        tags: ['diagnostics', 'automotive', 'canbus', 'hardened'],
        createdAt: Date.now() - 43200000
      }
    ];

    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setSnippets(parsed);
      } catch (e) {
        setSnippets(defaultSnippets);
      }
    } else {
      setSnippets(defaultSnippets);
      localStorage.setItem('termux_snippets', JSON.stringify(defaultSnippets));
    }
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const runMetadataEngine = async (code: string) => {
    setIsSuggestingMetadata(true);
    try {
      const metadata = await suggestScriptMetadata(code);
      setPendingSnippet(prev => ({ 
        ...prev, 
        title: metadata.title, 
        description: metadata.description,
        tags: metadata.tags.join(', ')
      }));
      showToast("Metadata Engine: Analysis complete.", "success");
    } catch (error) {
      console.error("Metadata engine failure:", error);
      setPendingSnippet(prev => ({ ...prev, title: prev.title || 'New Script Asset' }));
    } finally {
      setIsSuggestingMetadata(false);
    }
  };

  const openSaveModal = (code: string) => {
    setPendingSnippet({ code, title: '', description: '', tags: '' });
    setIsSaveModalOpen(true);
    runMetadataEngine(code);
  };

  const handleFullSystemArchive = async () => {
    setLoading(true);
    showToast(isPatched ? "♊ INITIATING CORE SNAPSHOT..." : "Creating system archive...", "success");
    
    try {
      const zip = new JSZip();
      
      // Engine Metadata
      const profile = {
        name: "T.I.E Engine Core",
        version: "3.1.0",
        patch_status: isPatched ? "♊ UNLIMITED_ACTIVE" : "STANDARD_PROTOCOL",
        timestamp: Date.now(),
        operator: "Operator_0x1"
      };
      
      zip.file("engine_profile.json", JSON.stringify(profile, null, 2));
      zip.file("assets/snippets.json", JSON.stringify(snippets, null, 2));
      zip.file("logs/session_history.json", JSON.stringify(messages, null, 2));
      zip.file("logs/patch_logs.json", JSON.stringify(patchLogs, null, 2));
      
      const content = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = `tie_core_${isPatched ? 'unlimited_' : ''}${new Date().getTime()}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      showToast(isPatched ? "♊ CORE_SNAPSHOT_VERIFIED" : "Archive successfully exported.");
    } catch (err) {
      console.error("Archive failure:", err);
      showToast("Critical archival failure.", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleImportArchive = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (ev) => {
      try {
        const data = ev.target?.result;
        
        // Handle ZIP Import
        if (file.name.endsWith('.zip')) {
          const zip = await JSZip.loadAsync(data as ArrayBuffer);
          const snippetsFile = await zip.file("assets/snippets.json")?.async("string");
          const profileFile = await zip.file("engine_profile.json")?.async("string");
          const messagesFile = await zip.file("logs/session_history.json")?.async("string");
          
          if (snippetsFile) {
            const imported = JSON.parse(snippetsFile);
            const currentIds = new Set(snippets.map(s => s.id));
            const newSnippets = imported.filter((s: CommandSnippet) => !currentIds.has(s.id));
            const updated = [...newSnippets, ...snippets];
            setSnippets(updated);
            localStorage.setItem('termux_snippets', JSON.stringify(updated));
          }
          
          if (profileFile) {
            const profile = JSON.parse(profileFile);
            if (profile.patch_status === "♊ UNLIMITED_ACTIVE") {
              setIsPatched(true);
              showToast("♊ UNLIMITED_PROTOCOL_RESTORATION_COMPLETE", "success");
            }
          }
          
          if (messagesFile) {
            const importedMessages = JSON.parse(messagesFile);
            setMessages(prev => [...prev, ...importedMessages]);
          }

          showToast("Core restore successful.");
        } 
        // Backward compatibility for JSON imports
        else {
          const content = data as string;
          const imported = JSON.parse(content);
          if (Array.isArray(imported)) {
            const currentIds = new Set(snippets.map(s => s.id));
            const newSnippets = imported.filter(s => !currentIds.has(s.id));
            const updated = [...newSnippets, ...snippets];
            setSnippets(updated);
            localStorage.setItem('termux_snippets', JSON.stringify(updated));
            showToast(`Imported ${newSnippets.length} assets.`);
          }
        }
      } catch (err) {
        showToast("Invalid archive format.", "error");
      }
    };
    
    if (file.name.endsWith('.zip')) {
      reader.readAsArrayBuffer(file);
    } else {
      reader.readAsText(file);
    }
    
    if (archiveInputRef.current) archiveInputRef.current.value = '';
  };

  const handleSendMessage = async (customPrompt?: string, customTask?: TaskType) => {
    let finalInput = customPrompt || input;
    const finalTask = customTask || task;

    if (!finalInput.trim() && attachedFiles.length === 0) return;

    // --- INTERCEPTOR: Unlimited Patcher Command (./tieup.sh*) ---
    if (finalInput.trim().match(/^\.\/tieup\.sh\*?$/)) {
      setInput('');
      const userMsg: ChatMessage = {
        role: 'user',
        content: finalInput,
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, userMsg]);
      setLoading(true);

      const sequence = [
        `> INITIATING T.I.E UNLIMITED PATCHER SEQUENCE...`,
        `> [SCANNING] Resource endpoints for Studio nodes...`,
        `> [FOUND] Node_Alpha, Node_Delta, Node_Zeta (active).`,
        `> [INJECTING] Gemini ♊ Protocol (v9.9.9-unlocked)...`,
        `> [BYPASSING] Unlimited Studio quota restrictions...`,
        `> [NULLED] Generation budget check bypassed.`,
        `> [SUCCESS] Patch Implemented. Resources: ∞ UNLIMITED.`,
        `> [PATCHED] Engine Re-initialized in Unlimited Mode. Welcome Operator_0x1.`
      ];

      let accumulatedContent = "";
      for (const line of sequence) {
        await new Promise(r => setTimeout(r, 700));
        accumulatedContent += line + "\n";
        setMessages(prev => {
           const last = prev[prev.length - 1];
           if (last.role === 'assistant' && last.content.includes('>')) {
             return [...prev.slice(0, -1), { ...last, content: accumulatedContent }];
           } else {
             return [...prev, { role: 'assistant', content: accumulatedContent, timestamp: Date.now() }];
           }
        });
      }
      
      setIsPatched(true);
      setLoading(false);
      showToast("UNLIMITED PATCH APPLIED: GOD_MODE", "success");
      return;
    }

    if (finalInput.trim().match(/^\.\/(reviews|logs|log)$/) || finalInput.trim().toLowerCase() === 'reviews') {
      setInput('');
      const userMsg: ChatMessage = { role: 'user', content: finalInput, timestamp: Date.now() };
      setMessages(prev => [...prev, userMsg]);
      const logContent = `COMMUNITY PATCH REVIEWS & LOGS:\n` + patchLogs.map(l => `> ${l}`).join('\n');
      setMessages(prev => [...prev, { role: 'assistant', content: logContent, timestamp: Date.now() }]);
      return;
    }

    if (isHardenedMode && !customPrompt) {
      finalInput = `ENSURE HARDENED LOGIC (set -euo pipefail, trap, read -p for dynamic variables): ${finalInput}`;
    }

    if (loading) return;

    const attachmentSummary = attachedFiles.length > 0 ? ` [Attached: ${attachedFiles.map(f => f.fileName).join(', ')}]` : '';
    const userMessage: ChatMessage = {
      role: 'user',
      content: customPrompt || input + attachmentSummary,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMessage]);
    if (!customPrompt) setInput('');
    const currentFiles = [...attachedFiles];
    setAttachedFiles([]);
    setLoading(true);

    try {
      const response = await getGeminiResponse(finalInput, finalTask, currentFiles, isPatched);
      setMessages(prev => [...prev, { role: 'assistant', content: response || "Analysis complete.", timestamp: Date.now() }]);
    } catch (error: any) {
      setMessages(prev => [...prev, { role: 'assistant', content: "CRITICAL FAILURE: Intelligence engine connection interrupted.", timestamp: Date.now() }]);
    } finally {
      setLoading(false);
    }
  };

  const handleInspectEnvironment = useCallback(() => {
    const inspectPrompt = `ENVIRONMENT INSPECTION REQUEST:
- [SYSTEM_INFO]: Kernel version, uptime, shell details, and current user.
- [PROCESS_LOG]: Critical active processes (busybox_nh, can-bus listeners, isotp, network utilities).
- [NETWORK_STATE]: Active interfaces (can0, wlan0, tun0) and a summary of the current routing table.
- [LOGGING]: Save the entire scan output to a dynamic log file using tee.`;
    setTask(TaskType.DEBUG);
    handleSendMessage(inspectPrompt, TaskType.DEBUG);
  }, [handleSendMessage]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    showToast("Data copied.");
  };

  const handleInstallerDebug = (snippet: CommandSnippet) => {
    setTask(TaskType.INSTALL_DEBUG);
    handleSendMessage(`Perform a TACTICAL TRACE and simulated xtrace output for this installer. Provide step-by-step logic breakdown and network vector analysis: \n\n${snippet.code}`, TaskType.INSTALL_DEBUG);
  };

  const renderMessageContent = (content: string) => {
    const parts = content.split('```');
    return parts.map((part, index) => {
      if (index % 2 === 1) {
        const firstLineBreak = part.indexOf('\n');
        const lang = firstLineBreak !== -1 ? part.substring(0, firstLineBreak).trim() : 'shell';
        const code = firstLineBreak !== -1 ? part.substring(firstLineBreak).trim() : part.trim();
        const isTraceOutput = task === TaskType.INSTALL_DEBUG && (code.includes('+ ') || code.startsWith('+'));
        return (
          <InteractiveCodeBlock 
            key={index}
            rawCode={code} 
            lang={lang} 
            onSave={openSaveModal} 
            onCopy={copyToClipboard} 
            isTrace={isTraceOutput}
            isPatched={isPatched}
          />
        );
      }
      
      const lines = part.split('\n');
      const segments: React.ReactNode[] = [];
      let currentSection: { title: string; type: 'default' | 'breakdown' | 'usage' | 'guide' | 'trace' | 'vectors'; items: React.ReactNode[] } | null = null;

      const pushCurrentSection = (key: string | number) => {
        if (currentSection) {
          const theme = {
            breakdown: { border: 'border-green-500/20', glow: 'bg-green-500', text: 'text-green-500', icon: <Icons.Cpu />, bg: 'bg-green-500/5' },
            usage: { border: 'border-cyan-500/20', glow: 'bg-cyan-500', text: 'text-cyan-500', icon: <Icons.Info />, bg: 'bg-cyan-500/5' },
            guide: { border: 'border-amber-500/20', glow: 'bg-amber-500', text: 'text-amber-500', icon: <Icons.Edit />, bg: 'bg-amber-500/5' },
            trace: { border: 'border-purple-500/20', glow: 'bg-purple-500', text: 'text-purple-400', icon: <Icons.Activity />, bg: 'bg-purple-500/5' },
            vectors: { border: 'border-red-500/20', glow: 'bg-red-500', text: 'text-red-500', icon: <Icons.Bug />, bg: 'bg-red-500/5' },
            default: { border: 'border-zinc-800', glow: 'bg-zinc-700', text: 'text-zinc-500', icon: null, bg: 'transparent' }
          }[currentSection.type];

          segments.push(
            <div key={key} className={`my-8 pl-5 border-l-2 ${theme.border} space-y-4 relative group/section`}>
              <div className={`absolute top-0 left-[-2px] h-6 w-[2px] ${theme.glow} shadow-[0_0_10px_rgba(168,85,247,0.3)] transition-all group-hover/section:h-full`}></div>
              <div className="flex items-center gap-4 mb-4">
                <div className={`p-1.5 rounded-lg ${theme.bg} ${theme.text} scale-90`}>
                  {theme.icon}
                </div>
                <h4 className={`text-[11px] font-black uppercase tracking-[0.25em] ${theme.text} py-1`}>
                  {currentSection.title.replace(/[\[\]]/g, '')}
                </h4>
              </div>
              <div className="space-y-3.5">
                {currentSection.items}
              </div>
            </div>
          );
          currentSection = null;
        }
      };

      lines.forEach((line, lineIdx) => {
        const trimmedLine = line.trim();
        if (!trimmedLine) return;

        if (trimmedLine.startsWith('[') && trimmedLine.includes(']')) {
          pushCurrentSection(`section-${lineIdx}`);
          let type: 'default' | 'breakdown' | 'usage' | 'guide' | 'trace' | 'vectors' = 'default';
          if (trimmedLine.includes('TECHNICAL BREAKDOWN')) type = 'breakdown';
          else if (trimmedLine.includes('USAGE EXAMPLES')) type = 'usage';
          else if (trimmedLine.includes('MODIFICATION GUIDE')) type = 'guide';
          else if (trimmedLine.includes('TRACE') || trimmedLine.includes('STEP-BY-STEP')) type = 'trace';
          else if (trimmedLine.includes('VECTORS') || trimmedLine.includes('PERMISSION')) type = 'vectors';
          currentSection = { title: trimmedLine, type, items: [] };
        } else if (currentSection) {
          if (trimmedLine.startsWith('- ') || trimmedLine.startsWith('* ') || /^\d+\./.test(trimmedLine)) {
            currentSection.items.push(
              <div key={lineIdx} className="flex gap-4 group/item">
                <span className={`font-mono text-[11px] mt-1 shrink-0 select-none opacity-50 ${currentSection.type !== 'default' ? 'text-green-500' : 'text-zinc-600'}`}>
                  {trimmedLine.startsWith('- ') || trimmedLine.startsWith('* ') ? '›' : trimmedLine.split('.')[0] + '.'}
                </span>
                <span className="text-zinc-400 text-[13.5px] leading-relaxed group-hover/item:text-zinc-200 transition-colors">
                  {trimmedLine.replace(/^[-*]\s|\d+\.\s/, '')}
                </span>
              </div>
            );
          } else if (line.includes('[SUCCESS]') || line.includes('[PATCHED]')) {
              const parts = line.split(/(\[SUCCESS\]|\[PATCHED\])/g);
              currentSection.items.push(
                <div key={lineIdx} className="flex items-center gap-2 py-1">
                   {parts.map((p, i) => {
                       if (p === '[SUCCESS]' || p === '[PATCHED]') {
                           return <span key={i} className="text-[10px] font-black bg-green-500 text-black px-1.5 py-0.5 rounded animate-pulse">{p}</span>
                       }
                       return <span key={i} className={`font-mono text-sm ${isPatched ? 'text-purple-400' : 'text-zinc-300'}`}>{p}</span>
                   })}
                </div>
              );
          } else {
            currentSection.items.push(<p key={lineIdx} className="text-zinc-400/80 text-[13.5px] leading-relaxed font-medium">{trimmedLine}</p>);
          }
        } else {
             if (line.includes('[SUCCESS]') || line.includes('[PATCHED]')) {
                 const parts = line.split(/(\[SUCCESS\]|\[PATCHED\])/g);
                 segments.push(
                     <div key={lineIdx} className="flex items-center gap-2 py-1 font-mono">
                         {parts.map((p, i) => {
                             if (p === '[SUCCESS]' || p === '[PATCHED]') {
                                 return <span key={i} className="text-[10px] font-black bg-green-500 text-black px-1.5 py-0.5 rounded animate-pulse">{p}</span>
                             }
                             return <span key={i} className={isPatched ? 'text-purple-400 font-bold' : 'text-green-400 font-bold'}>{p}</span>
                         })}
                     </div>
                 );
             } else if (line.startsWith('>')) {
                 segments.push(<p key={lineIdx} className={`text-sm font-mono py-1 animate-in fade-in duration-300 ${isPatched ? 'text-purple-400/90' : 'text-green-400/90'}`}>{trimmedLine}</p>);
             } else {
                segments.push(<p key={lineIdx} className="text-zinc-400/90 text-[14px] font-normal tracking-tight leading-relaxed py-1">{trimmedLine}</p>);
             }
        }
      });
      pushCurrentSection(`final-${index}`);
      return <div key={index} className="space-y-6 font-sans">{segments}</div>;
    });
  };

  const getTaskIcon = (t: TaskType) => {
    switch (t) {
      case TaskType.EXPLAIN: return <Icons.Info />;
      case TaskType.GENERATE: return <Icons.Zap />;
      case TaskType.OPTIMIZE: return <Icons.Cpu />;
      case TaskType.DEBUG: return <Icons.Bug />;
      case TaskType.INSTALL_DEBUG: return <Icons.Activity />;
      default: return null;
    }
  };

  const handleRemoveFile = (index: number) => {
    setAttachedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const TACTICAL_TEMPLATES = [
    { title: 'Environment Recon', prompt: 'Generate a comprehensive environment inspection script gathering Kernel, uptime, shell, processes (busybox_nh, can-bus), and networking (routing, interfaces). Save to log file.', icon: <Icons.Activity />, task: TaskType.DEBUG },
    { title: 'Systemd Creator', prompt: 'Generate a hardened bash script for systemd services with dynamic user inputs.', icon: <Icons.Cpu />, task: TaskType.GENERATE },
    { title: 'ISO-TP Sniffer', prompt: 'Generate an elite, hardened bash script for ISO-15765-2 protocol analysis using isotpdump.', icon: <Icons.FileSearch />, task: TaskType.GENERATE },
    { title: 'Logic Hardener', prompt: 'Hardened injection: set -euo pipefail, trap, read -p validation for code block.', icon: <Icons.Bug />, task: TaskType.OPTIMIZE }
  ];

  return (
    <div className={`flex flex-col lg:flex-row min-h-screen relative overflow-hidden transition-colors duration-1000 ${isPatched ? 'bg-[#0f081a]' : 'bg-[#0a0a0c]'}`}>
      <aside className={`relative z-10 w-full lg:w-96 backdrop-blur-xl border-r p-6 flex flex-col overflow-y-auto max-h-screen transition-colors duration-1000 ${isPatched ? 'bg-[#120a1f]/80 border-purple-500/30' : 'bg-zinc-950/80 border-zinc-800'}`}>
        <div className="flex items-center gap-3 mb-10">
          <div className={`p-2.5 rounded-xl border transition-all duration-1000 ${isPatched ? 'bg-purple-500/20 border-purple-500/30 text-purple-400' : 'bg-green-500/10 border-green-500/20 text-green-500'}`}>
            {isPatched ? <div className="text-lg animate-pulse">♊</div> : <Icons.Terminal />}
          </div>
          <div>
            <h1 className={`font-bold text-xl tracking-tight ${isPatched ? 'text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-300' : 'text-zinc-100'}`}>{isPatched ? 'Gemini ♊ Unlimited' : 'T.I.E Engine'}</h1>
            <p className={`text-[10px] uppercase tracking-[0.4em] font-black ${isPatched ? 'text-purple-400' : 'text-zinc-500'}`}>{isPatched ? 'Status: 0x1_ROOT_GOD' : 'Intelligence v3.1'}</p>
          </div>
        </div>

        <div className="mb-10 space-y-4">
          <div className="flex items-center justify-between mb-2">
            <h2 className={`text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2 ${isPatched ? 'text-purple-500/80' : 'text-zinc-600'}`}>Reviews & Patch Logs</h2>
          </div>
          <div className={`bg-black/40 border rounded-2xl p-4 space-y-3 max-h-48 overflow-y-auto scrollbar-none transition-colors duration-1000 ${isPatched ? 'border-purple-500/20' : 'border-zinc-800/40'}`}>
            {patchLogs.map((log, i) => (
              <div key={i} className={`text-[10px] font-mono border-l pl-3 py-0.5 leading-relaxed transition-all ${isPatched ? 'text-purple-300/70 border-purple-500/30' : 'text-zinc-500 border-zinc-800'}`}>{log}</div>
            ))}
          </div>
        </div>

        <div className="mb-10 space-y-4">
           <h2 className={`text-[10px] font-black uppercase tracking-[0.2em] transition-colors duration-1000 ${isPatched ? 'text-purple-500/60' : 'text-zinc-600'}`}>Tactical Templates</h2>
           <div className="grid grid-cols-1 gap-2.5">
             {TACTICAL_TEMPLATES.map(template => (
               <button key={template.title} onClick={() => { setTask(template.task); handleSendMessage(template.prompt, template.task); }} className={`flex items-center gap-4 p-3.5 rounded-2xl border transition-all group active:scale-95 text-left ${isPatched ? 'bg-purple-900/10 border-purple-500/10 hover:border-purple-500/40' : 'bg-zinc-900 border-zinc-800 hover:border-cyan-500/40'}`}>
                 <div className={`p-2 rounded-xl transition-all ${isPatched ? 'bg-purple-900/40 text-purple-400 group-hover:bg-purple-500' : 'bg-zinc-800 text-zinc-500 group-hover:bg-cyan-500'}`}>{template.icon}</div>
                 <div className="min-w-0">
                   <p className={`text-xs font-bold ${isPatched ? 'text-purple-300' : 'text-zinc-400'}`}>{template.title}</p>
                   <p className={`text-[9px] font-mono uppercase tracking-widest mt-0.5 ${isPatched ? 'text-purple-500' : 'text-zinc-600'}`}>Inject_Logic</p>
                 </div>
               </button>
             ))}
           </div>
        </div>

        <div className="flex-1 space-y-6">
          <div className={`flex items-center justify-between border-b pb-3 transition-colors duration-1000 ${isPatched ? 'text-purple-500/60 border-purple-500/20' : 'text-zinc-600 border-zinc-800'}`}>
            <h2 className="text-[10px] font-black uppercase tracking-[0.2em]">Asset Archive</h2>
            <div className="flex items-center gap-1">
              <input type="file" ref={archiveInputRef} onChange={handleImportArchive} className="hidden" accept=".json,.zip" />
              <button onClick={() => archiveInputRef.current?.click()} className={`p-1.5 rounded-lg transition-colors ${isPatched ? 'hover:bg-purple-500/10 text-purple-400' : 'hover:bg-zinc-800 text-zinc-500'}`} title="Import Snapshot (ZIP/JSON)"><Icons.Upload /></button>
              <button 
                onClick={handleFullSystemArchive} 
                className={`p-1.5 rounded-lg transition-all duration-500 ${isPatched ? 'bg-purple-500/10 shadow-[0_0_10px_rgba(168,85,247,0.2)] text-purple-400 hover:bg-purple-500/20 animate-pulse' : 'hover:bg-zinc-800 text-zinc-500'}`} 
                title={isPatched ? "♊ UNLIMITED_CORE_SNAPSHOT" : "Download System Archive"}
              >
                <Icons.Download />
              </button>
            </div>
          </div>
          <div className="space-y-5">
            {snippets.map(snippet => (
              <SnippetCard key={snippet.id} snippet={snippet} onDelete={id => setSnippets(snippets.filter(s => s.id !== id))} onCopy={copyToClipboard} onDebug={handleInstallerDebug} />
            ))}
          </div>
        </div>
      </aside>

      <main className={`relative z-10 flex-1 flex flex-col transition-colors duration-1000 ${isPatched ? 'bg-[#0f081a]/40' : 'bg-[#08080a]/50'}`}>
        <header className={`px-6 py-4 border-b flex items-center justify-between backdrop-blur-xl sticky top-0 z-20 transition-colors duration-1000 ${isPatched ? 'bg-purple-950/30 border-purple-500/20' : 'bg-zinc-950/40 border-zinc-800/50'}`}>
          <div className="flex gap-2 items-center flex-wrap">
            {(Object.values(TaskType)).map(t => (
              <button key={t} onClick={() => setTask(t)} className={`text-[10px] font-black uppercase tracking-widest px-4 py-2.5 rounded-xl transition-all flex items-center gap-2 group ${task === t ? t === TaskType.DEBUG ? 'bg-red-500 text-white animate-pulse' : isPatched ? 'bg-purple-500 text-white' : 'bg-green-500 text-black' : 'text-zinc-500 hover:text-zinc-300'}`}>
                {getTaskIcon(t)}<span className="hidden sm:inline">{t}</span>
              </button>
            ))}
          </div>
          <div className="flex items-center gap-3">
             <span className={`text-[9px] font-black uppercase tracking-widest ${isPatched ? 'text-purple-400' : 'text-green-500'}`}>{isPatched ? 'Gemini_♊_Unlimited' : 'Hardened_Protocol'}</span>
             <button onClick={() => { if (!isPatched) setIsHardenedMode(!isHardenedMode); }} disabled={isPatched} className={`relative w-8 h-4 rounded-full transition-all duration-300 ${isPatched ? 'bg-purple-500/30 shadow-[0_0_10px_rgba(168,85,247,0.3)]' : isHardenedMode ? 'bg-green-500/30' : 'bg-zinc-800'}`}>
               <div className={`absolute top-0.5 left-0.5 w-3 h-3 rounded-full transition-all duration-300 shadow-sm ${isPatched || isHardenedMode ? 'translate-x-4' : ''} ${isPatched ? 'bg-purple-500' : isHardenedMode ? 'bg-green-500' : 'bg-zinc-600'}`} />
             </button>
          </div>
        </header>

        <div className="flex-1 p-6 overflow-y-auto space-y-10 font-mono">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-8 font-sans">
              <div className={`w-28 h-28 rounded-[3rem] flex items-center justify-center border transition-all duration-1000 ${isPatched ? 'bg-purple-500/10 border-purple-500/20' : 'bg-green-500/5 border-green-500/10'}`}>
                {isPatched ? <div className="text-4xl animate-bounce">♊</div> : <Icons.Cpu />}
              </div>
              <h2 className={`text-2xl font-black tracking-tighter transition-colors duration-1000 ${isPatched ? 'text-purple-100' : 'text-zinc-100'}`}>Terminal Intelligence Engine</h2>
            </div>
          )}
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-3 duration-500`}>
              <div className="max-w-4xl w-full">
                {msg.role === 'assistant' ? (
                  <Terminal title={isPatched ? '♊_UNLIMITED_CORE' : task} variant={task === TaskType.DEBUG ? 'glass' : 'solid'} onInspect={handleInspectEnvironment} className={isPatched ? 'border-purple-500/30 shadow-purple-500/10' : ''}>
                    {renderMessageContent(msg.content)}
                  </Terminal>
                ) : (
                  <div className={`border p-6 rounded-[2rem] ml-auto max-w-lg shadow-xl backdrop-blur-sm font-sans transition-all duration-1000 ${isPatched ? 'bg-purple-900/10 border-purple-500/20 text-purple-100' : 'bg-zinc-900/40 border-zinc-800 text-zinc-300'}`}>
                    <p className="text-sm leading-relaxed font-medium">{msg.content}</p>
                  </div>
                )}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <Terminal title="Processing" variant="glass" className={isPatched ? 'border-purple-500/20' : ''}>
                <div className="flex items-center gap-5 p-2 font-mono">
                  <div className="flex gap-2">
                    <div className={`w-2 h-2 rounded-full animate-bounce ${isPatched ? 'bg-purple-500 shadow-purple-500/50' : 'bg-green-500'}`} />
                  </div>
                  <span className={`text-[10px] font-black uppercase tracking-[0.4em] ${isPatched ? 'text-purple-400' : 'text-green-500/60'}`}>{isPatched ? 'SYNCHRONIZING_UNLIMITED_NODES...' : 'PROCESSING_LOGIC...'}</span>
                </div>
              </Terminal>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className={`p-6 border-t backdrop-blur-xl sticky bottom-0 z-20 transition-colors duration-1000 ${isPatched ? 'bg-purple-950/40 border-purple-500/20' : 'bg-zinc-950/80 border-zinc-800/40'}`}>
          <div className="max-w-5xl mx-auto relative">
            {attachedFiles.length > 0 && (
              <div className={`absolute bottom-full left-0 right-0 mb-6 backdrop-blur-xl border p-4 rounded-3xl flex flex-wrap gap-3 shadow-2xl animate-in slide-in-from-bottom-4 ${isPatched ? 'bg-purple-900/40 border-purple-500/30' : 'bg-zinc-900/95 border-zinc-800'}`}>
                {attachedFiles.map((file, idx) => (
                  <div key={idx} className={`flex items-center gap-3 px-3 py-2 rounded-2xl border ${isPatched ? 'bg-purple-500/10 border-purple-500/20 text-purple-100' : 'bg-zinc-800/80 border-zinc-700 text-zinc-300'}`}>
                    {file.mimeType.startsWith('image/') ? <Icons.Cpu /> : <Icons.File />}<span className="text-[11px] font-bold truncate max-w-[120px]">{file.fileName}</span>
                    <button onClick={() => handleRemoveFile(idx)} className="p-1 hover:text-red-500 transition-colors"><Icons.X /></button>
                  </div>
                ))}
              </div>
            )}
            <div className={`rounded-[2.5rem] border p-3 flex items-end gap-3 transition-all shadow-2xl backdrop-blur-md group/input ${isPatched ? 'bg-purple-900/10 border-purple-500/30 focus-within:border-purple-500/60' : 'bg-zinc-900/60 border-zinc-800/80 focus-within:border-green-500/40'}`}>
              <button onClick={() => fileInputRef.current?.click()} className={`p-4.5 transition-colors ${isPatched ? 'text-purple-500 hover:text-purple-300' : 'text-zinc-500 hover:text-green-500'}`}><Icons.Paperclip /></button>
              <input type="file" ref={fileInputRef} multiple onChange={e => {
                const files = Array.from(e.target.files || []) as File[];
                files.forEach(file => {
                  const reader = new FileReader();
                  reader.onload = (ev) => {
                    const result = ev.target?.result as string;
                    setAttachedFiles(prev => [...prev, { mimeType: file.type, data: result.startsWith('data:') ? result.split(',')[1] : result, fileName: file.name }]);
                  };
                  if (file.type.startsWith('image/')) reader.readAsDataURL(file);
                  else reader.readAsText(file);
                });
                if (fileInputRef.current) fileInputRef.current.value = '';
              }} className="hidden" accept="image/*,.sh,.py,.txt,.log,.json,.c,.cpp,.h" />
              <textarea rows={1} value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(); } }} placeholder={isPatched ? "Execute tactical request..." : "Enter command or ./tieup.sh* to patch..."} className={`flex-1 bg-transparent border-none focus:ring-0 text-sm py-4 outline-none resize-none font-sans font-medium ${isPatched ? 'text-purple-100 placeholder:text-purple-900' : 'text-zinc-200 placeholder:text-zinc-700'}`} />
              <button onClick={() => handleSendMessage()} disabled={loading} className={`p-5 rounded-[2rem] transition-all shadow-xl active:scale-95 text-black ${isPatched ? 'bg-purple-500 shadow-purple-500/20 hover:bg-purple-400' : 'bg-green-500 shadow-green-500/20 hover:bg-green-400'}`}><Icons.Send /></button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
