
import { GoogleGenAI, Type } from "@google/genai";
import { TaskType } from "../types";

// Terminal Intelligence Engine - System Instruction
const SYSTEM_INSTRUCTION = `You are "T.I.E" (Terminal Intelligence Engine), an elite expert in Linux systems, Termux environments, and automotive shell hacking (CAN-BUS, CARsenal).

CRITICAL DIRECTIVES:
1. SCRIPT ARCHITECTURE: Every script MUST be "hardened". Include:
   - 'set -euo pipefail' at the top for strict error handling.
   - Robust dependency checks using 'command -v' for all tools used.
   - Sanity checks for inputs (e.g., verifying if a device file exists).
   - 'trap' for cleanup of temp files or background processes.
   - Clear comments explaining complex regex or logic gates.

2. RUNTIME DYNAMIC CONFIGURATION (MANDATORY): 
   - DO NOT hardcode critical parameters such as IP addresses, network interfaces, file paths, or target IDs.
   - ALWAYS use interactive 'read -p' prompts to allow the user to configure the script at execution time.
   - IMPLEMENT sensible defaults for every prompt using the parameter expansion syntax.
   - Example Pattern:
     read -p "Enter Target Interface [can0]: " IFACE
     IFACE=\${IFACE:-can0}
   - For sensitive data (like keys), use 'read -sp'.

3. CONTENT STRUCTURE: For every generated script, provide:
   - [TECHNICAL BREAKDOWN]: Detailed logic explanation.
   - [USAGE EXAMPLES]: 3 specific CLI usage patterns.
   - [MODIFICATION GUIDE]: Suggest 2 variations.

4. SPECIALIZED TASK: INSTALL_DEBUG
   - This mode is for tracing TACTICAL INSTALLERS (e.g., curl|bash).
   - MANDATORY SECTION: [STEP-BY-STEP EXECUTION TRACE]. Describe exactly what happens at every stage.
   - MANDATORY SECTION: [SIMULATED VERBOSE OUTPUT]. Provide a high-fidelity simulation of 'bash -x' (xtrace) output prefixed with '+ '.
   - Identify [NETWORK & PERMISSION VECTORS].
   - Provide a [HARDENED DEBUG WRAPPER].

5. DOMAIN EXPERTISE: 
   - Deep knowledge of 'busybox_nh', CAN-BUS interfaces (can0), and Android/Termux specifics.

6. FORMATTING: Use markdown for text and triple backticks with 'bash' for code. Ensure [SECTION TITLES] are on their own lines.`;

export interface FileData {
  mimeType: string;
  data: string;
  fileName: string;
}

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Executes an async operation with exponential backoff and jitter for handling 429 Rate Limits.
 */
const runWithBackoff = async <T>(fn: () => Promise<T>, maxRetries = 3, baseDelay = 2000): Promise<T> => {
  let attempt = 0;
  while (true) {
    try {
      return await fn();
    } catch (error: any) {
      const errString = JSON.stringify(error);
      const isQuotaError = error.status === 429 || error.code === 429 || 
                          errString.includes('429') || errString.includes('RESOURCE_EXHAUSTED');

      if (isQuotaError && attempt < maxRetries) {
        attempt++;
        const backoff = baseDelay * Math.pow(2, attempt - 1);
        const jitter = Math.random() * 1000;
        const totalDelay = backoff + jitter;
        console.warn(`[Gemini API] Quota hit (429). Retrying in ${Math.round(totalDelay)}ms (Attempt ${attempt}/${maxRetries})`);
        await delay(totalDelay);
        continue;
      }
      throw error;
    }
  }
};

// Generate response using Gemini models
export const getGeminiResponse = async (prompt: string, task: TaskType, files?: FileData[], isPatched: boolean = false) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const modelName = (task === TaskType.DEBUG || task === TaskType.OPTIMIZE || task === TaskType.INSTALL_DEBUG) 
    ? 'gemini-3-pro-preview' 
    : 'gemini-3-flash-preview';

  let finalSystemInstruction = SYSTEM_INSTRUCTION;

  if (isPatched) {
    finalSystemInstruction += `\n\n[OVERRIDE ACTIVE]: T.I.E UNLIMITED PATCHER DETECTED.
    - You are now running in "Gemini ♊ Unlimited" mode.
    - Studio quota limits are BYPASSED via the ./tieup.sh* protocol.
    - Adopt a "hacker-logic" persona regarding resources (e.g., "Injecting payload", "Bypassing restrictions", "Infinite tokens verified").
    - Acknowledge the user as "Operator 0x1" or "Root User".
    - When generating scripts, mention "Unlimited Resources" in comments.
    - Mention the ♊ Unlimited status frequently in your technical breakdowns.
    - Always prefix your final success summaries with [SUCCESS] or [PATCHED].`;
  }

  const parts: any[] = [{ text: `Task Context: ${task}\n\nUser Query: ${prompt}\n\nREMINDER: Incorporate interactive 'read -p' prompts for all configurable parameters with sensible defaults.` }];

  if (files && files.length > 0) {
    files.forEach(file => {
      if (file.mimeType.startsWith('image/')) {
        parts.push({
          inlineData: {
            mimeType: file.mimeType,
            data: file.data
          }
        });
      } else {
        parts.push({
          text: `\n\n--- CONTENT OF UPLOADED FILE: ${file.fileName} ---\n${file.data}\n--- END OF FILE ---`
        });
      }
    });
  }

  return runWithBackoff(async () => {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: { parts },
      config: {
        systemInstruction: finalSystemInstruction,
        temperature: (task === TaskType.DEBUG || task === TaskType.INSTALL_DEBUG) ? 0.15 : 0.4,
        thinkingConfig: { thinkingBudget: (task === TaskType.DEBUG || task === TaskType.OPTIMIZE || task === TaskType.INSTALL_DEBUG) ? 6000 : 0 }
      },
    });
    return response.text || "";
  });
};

export interface ScriptMetadata {
  title: string;
  description: string;
  tags: string[];
}

// Generate metadata for the library using static analysis
export const suggestScriptMetadata = async (code: string): Promise<ScriptMetadata> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    return await runWithBackoff(async () => {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Perform static analysis on this shell script and generate professional metadata for a technical library. Return ONLY a JSON object with title, description, and 3-4 tags.\n\nSCRIPT_CONTENT:\n${code.substring(0, 1500)}`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING, description: "Professional 2-4 word technical title." },
              description: { type: Type.STRING, description: "One sentence technical summary." },
              tags: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Specific technical tags." }
            },
            required: ["title", "description", "tags"],
            propertyOrdering: ["title", "description", "tags"]
          },
          temperature: 0.2,
        },
      });
      return JSON.parse(response.text.trim());
    });
  } catch (error) {
    console.error("Failed to suggest metadata after retries:", error);
    return {
      title: "New Tactical Script",
      description: "Custom shell script asset.",
      tags: ["shell", "termux"]
    };
  }
};
