
import React, { useState } from 'react';
import { Icons } from '../constants';

interface TerminalProps {
  children: React.ReactNode;
  /** The text to display in the header bar. Defaults to 'bash'. */
  title?: string;
  /** Visual style variant. 'solid' for deep black, 'glass' for translucent. Defaults to 'solid'. */
  variant?: 'solid' | 'glass';
  /** Tailwind class for max-height. Defaults to 'max-h-[500px]'. */
  maxHeight?: string;
  /** Additional Tailwind classes for the outer container. */
  className?: string;
  /** Callback triggered when the 'Inspect' action is clicked. */
  onInspect?: () => void;
}

/**
 * A highly customizable, terminal-themed container for code or logs with fullscreen support.
 */
const Terminal: React.FC<TerminalProps> = ({ 
  children, 
  title = 'bash', 
  variant = 'solid',
  maxHeight = 'max-h-[500px]',
  className = '',
  onInspect
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);

  const bgStyles = variant === 'glass' 
    ? 'bg-zinc-950/80 backdrop-blur-xl' 
    : 'bg-zinc-950';

  const toggleFullscreen = () => setIsFullscreen(!isFullscreen);

  return (
    <div className={`
      flex flex-col overflow-hidden transition-all duration-300
      ${isFullscreen 
        ? 'fixed inset-0 z-[100] bg-zinc-950 rounded-none' 
        : `rounded-xl border border-zinc-800/80 shadow-2xl terminal-glow ${className}`}
    `}>
      {/* Header Bar */}
      <div className={`
        px-4 py-2.5 border-b border-zinc-800/50 flex items-center justify-between backdrop-blur-sm
        ${isFullscreen ? 'bg-zinc-900 px-6 py-4' : 'bg-zinc-900/60'}
      `}>
        {/* MacOS Style Buttons (only show in normal mode) */}
        <div className="flex gap-2 min-w-[50px]">
          {!isFullscreen && (
            <>
              <div className="w-2.5 h-2.5 rounded-full bg-red-500/20 border border-red-500/30"></div>
              <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/20 border border-yellow-500/30"></div>
              <div className="w-2.5 h-2.5 rounded-full bg-green-500/20 border border-green-500/30"></div>
            </>
          )}
        </div>
        
        {/* Centered Title */}
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-green-500 shadow-[0_0_5px_rgba(34,197,94,0.5)]"></div>
          <span className={`font-mono font-bold text-zinc-400 uppercase tracking-[0.2em] ${isFullscreen ? 'text-sm' : 'text-[10px]'}`}>
            {title}
          </span>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3 text-zinc-500 min-w-[50px] justify-end">
           {onInspect && (
             <button 
               onClick={onInspect}
               className="hover:text-cyan-400 transition-colors p-1 group relative"
               title="T.I.E Environment Scan"
             >
               <Icons.Activity />
               <span className="absolute -bottom-8 right-0 bg-zinc-900 text-[8px] px-2 py-1 rounded border border-zinc-800 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
                 ENV_INSPECT
               </span>
             </button>
           )}
           <button 
             onClick={toggleFullscreen}
             className="hover:text-green-500 transition-colors p-1"
             title={isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen"}
           >
             {isFullscreen ? <Icons.Minimize /> : <Icons.Maximize />}
           </button>
           {!isFullscreen && (
             <div className="hidden sm:flex gap-1.5">
               <div className="w-3 h-0.5 bg-zinc-700 rounded-full"></div>
               <div className="w-3 h-0.5 bg-zinc-700 rounded-full"></div>
             </div>
           )}
        </div>
      </div>
      
      {/* Body Content */}
      <div className={`
        ${bgStyles} 
        font-mono text-sm leading-relaxed
        overflow-y-auto 
        scrollbar-thin scrollbar-thumb-zinc-800 scrollbar-track-transparent
        ${isFullscreen 
          ? 'flex-1 p-6 sm:p-10 text-base max-h-none' 
          : `p-4 sm:p-5 lg:p-6 ${maxHeight}`}
      `}>
        {children}
      </div>
    </div>
  );
};

export default Terminal;
