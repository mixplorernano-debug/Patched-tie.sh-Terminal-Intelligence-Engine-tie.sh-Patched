
import React from 'react';
import { CommandSnippet } from '../types';
import { Icons } from '../constants';

interface SnippetCardProps {
  snippet: CommandSnippet;
  onDelete: (id: string) => void;
  onCopy: (code: string) => void;
  onDebug?: (snippet: CommandSnippet) => void;
}

const SnippetCard: React.FC<SnippetCardProps> = ({ snippet, onDelete, onCopy, onDebug }) => {
  const lineCount = snippet.code.split('\n').length;
  const isInstaller = snippet.tags.includes('installer') || snippet.code.includes('| bash') || snippet.code.includes('| sh');
  
  const formattedDate = new Intl.DateTimeFormat('en-US', { 
    month: 'short', 
    day: 'numeric' 
  }).format(new Date(snippet.createdAt));

  return (
    <div className={`
      relative p-5 rounded-2xl group transition-all duration-300 shadow-sm border
      ${isInstaller 
        ? 'bg-cyan-500/5 border-cyan-500/30 hover:border-cyan-500/60 hover:bg-cyan-500/10 shadow-cyan-500/5' 
        : 'bg-zinc-900/40 border-zinc-800/60 hover:border-green-500/40 hover:bg-zinc-900/60 hover:shadow-green-500/5'}
    `}>
      {/* Tactical Badge for Installers */}
      {isInstaller && (
        <div className="absolute top-0 right-4 -translate-y-1/2 bg-cyan-500 text-black text-[8px] font-black px-2 py-0.5 rounded uppercase tracking-[0.2em] shadow-lg shadow-cyan-500/20">
          Tactical_Deploy
        </div>
      )}

      {/* Header with Title and Actions */}
      <div className="flex justify-between items-start gap-4 mb-3">
        <div className="flex-1 min-w-0">
          <h3 className={`font-bold text-sm truncate group-hover:text-white transition-colors ${isInstaller ? 'text-cyan-400' : 'text-zinc-100'}`}>
            {snippet.title}
          </h3>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-[10px] text-zinc-500 font-mono uppercase tracking-wider">{formattedDate}</span>
            <span className="text-[10px] text-zinc-600">•</span>
            <span className="text-[10px] text-zinc-500 font-mono uppercase tracking-wider">{lineCount} {lineCount === 1 ? 'line' : 'lines'}</span>
          </div>
        </div>
        
        <div className="flex gap-1 shrink-0 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity">
          {isInstaller && onDebug && (
            <button 
              onClick={() => onDebug(snippet)}
              className="p-2 rounded-lg transition-colors text-amber-500 hover:bg-amber-500/10"
              title="Trace Installation"
            >
              <Icons.Activity />
            </button>
          )}
          <button 
            onClick={() => onCopy(snippet.code)}
            className={`p-2 rounded-lg transition-colors ${isInstaller ? 'text-cyan-500 hover:bg-cyan-500/10' : 'text-zinc-500 hover:bg-zinc-800 hover:text-green-400'}`}
            title="Copy Code"
          >
            <Icons.Copy />
          </button>
          <button 
            onClick={() => onDelete(snippet.id)}
            className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-red-400 transition-colors"
            title="Delete"
          >
            <Icons.Trash />
          </button>
        </div>
      </div>

      {/* Description */}
      <p className="text-xs text-zinc-400 leading-relaxed mb-4 line-clamp-2 italic">
        {snippet.description || "No description provided."}
      </p>

      {/* Structured Code Preview */}
      <div className={`relative rounded-xl border overflow-hidden group/code ${isInstaller ? 'border-cyan-500/20 bg-black/60' : 'border-zinc-800 bg-black/40'}`}>
        <div className={`flex items-center justify-between px-3 py-1.5 border-b ${isInstaller ? 'bg-cyan-500/5 border-cyan-500/10' : 'bg-zinc-900/50 border-zinc-800'}`}>
           <span className={`text-[9px] font-mono font-bold uppercase tracking-widest ${isInstaller ? 'text-cyan-500/60' : 'text-zinc-500'}`}>
            {isInstaller ? 'TACTICAL_ONE_LINER' : 'shell'}
           </span>
           <div className={`w-1.5 h-1.5 rounded-full ${isInstaller ? 'bg-cyan-500 animate-pulse' : 'bg-zinc-700'}`}></div>
        </div>
        <div className="p-3 font-mono text-[11px] overflow-hidden">
          <code className={`block whitespace-pre ${isInstaller ? 'text-cyan-400/90' : 'text-green-400/80'}`}>
            {snippet.code.length > 80 ? snippet.code.substring(0, 80).trim() + '...' : snippet.code}
          </code>
        </div>
      </div>

      {/* Tags Footer */}
      {snippet.tags.length > 0 && (
        <div className="flex gap-1.5 mt-4 flex-wrap">
          {snippet.tags.map(tag => (
            <span 
              key={tag} 
              className={`text-[9px] font-bold px-2 py-0.5 rounded-md border transition-colors cursor-default
                ${isInstaller 
                  ? 'bg-cyan-500/5 text-cyan-500/70 border-cyan-500/10 hover:border-cyan-500/30' 
                  : 'bg-green-500/5 text-green-500/70 border-green-500/10 hover:border-green-500/30'}`}
            >
              {tag.toUpperCase()}
            </span>
          ))}
        </div>
      )}
    </div>
  );
};

export default SnippetCard;
