
export interface CommandSnippet {
  id: string;
  title: string;
  code: string;
  description: string;
  tags: string[];
  createdAt: number;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  isCode?: boolean;
}

export enum TaskType {
  EXPLAIN = 'EXPLAIN',
  GENERATE = 'GENERATE',
  OPTIMIZE = 'OPTIMIZE',
  DEBUG = 'DEBUG',
  INSTALL_DEBUG = 'INSTALL_DEBUG'
}
